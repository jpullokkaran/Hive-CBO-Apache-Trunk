package org.apache.hadoop.hive.ql.optimizer.optiq.reloperators;

import java.util.LinkedList;
import java.util.List;

import org.apache.hadoop.hive.ql.optimizer.optiq.OptiqTraitsUtil;
import org.eigenbase.relopt.RelOptCluster;
import org.eigenbase.relopt.RelTraitSet;

public class HiveIRShuffleRel extends HiveIRRel {
  private final List<Integer> m_partCols = new LinkedList<Integer>();

  //TODO: Handle expressions as partition cols (x+Y)
  public HiveIRShuffleRel(RelOptCluster cluster, RelTraitSet traitSet, List<Integer> partCols, HiveRel child) {
    super(cluster, OptiqTraitsUtil.getAggregateTraitSet(cluster, traitSet, partCols, null, child), child);
    m_partCols.addAll(partCols);
  }

  @Override
  public Double getEstimatedMemUsageInVertex() {
    //TODO: Even in shuffle case, Hive would store all data for a given key value from other relations will be kept in memory (except for the streaming side)
    // So actual mem consumption depends on a) If this is the streaming side b) what are the average size of partition from other relations
    return ((HiveRel)getChild()).getColumnAvgSize();
  }

  @Override
  public Integer getDegreeOfParallelization() {
    return 0;
  }

  @Override
  public Long getNDV(List<Integer> colOrderLst) {
    return ((HiveRel)getChild()).getNDV(colOrderLst);
  }


  @Override
  public List<Integer> getPartCols() {
    return m_partCols;
  }
}
