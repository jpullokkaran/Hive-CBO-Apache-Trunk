package org.apache.hadoop.hive.ql.optimizer.optiq.reloperators;

import java.util.List;

import org.apache.hadoop.hive.ql.optimizer.optiq.RelBucketing;
import org.eigenbase.rel.RelCollation;
import org.eigenbase.rel.SingleRel;
import org.eigenbase.relopt.RelOptCluster;
import org.eigenbase.relopt.RelTraitSet;

public abstract class HiveIRRel extends SingleRel implements HiveRel {

  public HiveIRRel(RelOptCluster cluster, RelTraitSet traitSet, HiveRel child) {
    super(cluster, traitSet, child);
  }

  @Override
  public void implement(Implementor implementor) {
    // TODO Auto-generated method stub
  }

  @Override
  public Double getColumnAvgSize() {
    return ((HiveRel)getChild()).getColumnAvgSize();
  }

  @Override
  public List<Double> getColumnAvgSize(List<Integer> projIndxLst) {
    return ((HiveRel)getChild()).getColumnAvgSize(projIndxLst);
  }

  @Override
  public Double getColumnAvgSize(int projIndx) {
    return ((HiveRel)getChild()).getColumnAvgSize(projIndx);
  }

  @Override
  public boolean propagateBucketingTraitUpwardsViaTransformation(List<Integer> bucketingCols, List<Integer> bucketSortCols){
    return false;
  }

  @Override
  public boolean propagateSortingTraitUpwardsViaTransformation(List<Integer> sortingCols) {
    return false;
  }

  @Override
  public boolean shouldPropagateTraitFromChildViaTransformation(RelBucketing bucketTraitFromChild) {
    return false;
  }

  @Override
  public boolean shouldPropagateTraitFromChildViaTransformation(RelCollation sortTraitFromChild) {
    return false;
  }
}
