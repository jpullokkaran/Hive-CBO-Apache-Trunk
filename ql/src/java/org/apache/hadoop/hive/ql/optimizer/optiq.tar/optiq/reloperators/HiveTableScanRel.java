package org.apache.hadoop.hive.ql.optimizer.optiq.reloperators;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.hadoop.hive.ql.optimizer.optiq.OptiqTraitsUtil;
import org.apache.hadoop.hive.ql.optimizer.optiq.RelBucketing;
import org.apache.hadoop.hive.ql.optimizer.optiq.RelOptHiveTable;
import org.apache.hadoop.hive.ql.optimizer.optiq.stats.OptiqStatsUtil;
import org.eigenbase.rel.RelCollation;
import org.eigenbase.rel.RelNode;
import org.eigenbase.rel.TableAccessRelBase;
import org.eigenbase.relopt.RelOptCluster;
import org.eigenbase.relopt.RelOptCost;
import org.eigenbase.relopt.RelOptPlanner;
import org.eigenbase.relopt.RelTraitSet;
import org.eigenbase.reltype.RelDataType;

/**
 * Relational expression representing a scan of a HiveDB collection.
 *
 * <p>
 * Additional operations might be applied, using the "find" or "aggregate" methods.
 * </p>
 */
public class HiveTableScanRel extends TableAccessRelBase implements HiveRel {
  /*
   * TODO: 1. Support Projection pruning
   * 2. Support Partition pruning (Filter push down to TS)
   */

  private final RelDataType m_rowType;

  private final List<Double> m_columnSizeLst = new LinkedList<Double>();
  private final Double m_avgSize;

  /**
   * Creates a HiveTableScan.
   *
   * @param cluster
   *          Cluster
   * @param traitSet
   *          Traits
   * @param table
   *          Table
   * @param table
   *          HiveDB table
   */
  public HiveTableScanRel(RelOptCluster cluster, RelTraitSet traitSet,
      RelOptHiveTable table, RelDataType rowtype) {
    super(cluster, OptiqTraitsUtil.getTableScanTraitSet(cluster, traitSet, table, rowtype), table);
    this.m_rowType = rowtype;
    assert getConvention() == HiveRel.CONVENTION;

    Map<String, Double> sizeMap = ((RelOptHiveTable) table).getColumnAvgSize(m_rowType
        .getFieldNames());
    Double avgSz = 0.0;
    for (Entry<String, Double> entry : sizeMap.entrySet()) {
      avgSz += entry.getValue();
      m_columnSizeLst.add(entry.getValue());
    }
    m_avgSize = avgSz;
  }

  @Override
  public RelNode copy(RelTraitSet traitSet, List<RelNode> inputs) {
    assert inputs.isEmpty();
    return this;
  }

  @Override
  public RelOptCost computeSelfCost(RelOptPlanner planner) {
    /*
     * return super.computeSelfCost(planner).multiplyBy(
     * .1 * f);
     */
    return null;
  }

  @Override
  public void register(RelOptPlanner planner) {

  }

  public void implement(Implementor implementor) {

  }

  @Override
  // TODO: Need to handle partition/scan pruning
  public double getRows() {
    return ((RelOptHiveTable) table).getRowCount();
  }

  @Override
  public Double getColumnAvgSize() {
    return m_avgSize;
  }

  @Override
  public List<Double> getColumnAvgSize(List<Integer> projIndxLst) {
    if (projIndxLst != null) {
      List<Double> sizeLst = new LinkedList<Double>();

      for (Integer projIdx : projIndxLst) {
        sizeLst.add(m_columnSizeLst.get(projIdx));
      }

      return sizeLst;
    } else {
      return m_columnSizeLst;
    }
  }

  @Override
  public Double getColumnAvgSize(int projIndx) {
    return m_columnSizeLst.get(projIndx);
  }


  @Override
  public Double getEstimatedMemUsageInVertex() {
    return 0.0;
  }

  @Override
  public Integer getDegreeOfParallelization() {
    return 0;
  }

  @Override
  public Long getNDV(List<Integer> colOrderLst) {
    return OptiqStatsUtil.computeNDV(this, colOrderLst);
  }

  @Override
  public boolean propagateBucketingTraitUpwardsViaTransformation(List<Integer> bucketingCols, List<Integer> bucketSortCols){
    return false;
  }

  @Override
  public boolean propagateSortingTraitUpwardsViaTransformation(List<Integer> sortingCols) {
    return false;
  }

  @Override
  public boolean shouldPropagateTraitFromChildViaTransformation(RelBucketing bucketTraitFromChild) {
    return false;
  }

  @Override
  public boolean shouldPropagateTraitFromChildViaTransformation(RelCollation sortTraitFromChild) {
    return false;
  }
}

// End HiveTableScan.java
