package org.apache.hadoop.hive.ql.optimizer.optiq;

import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveAggregateRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveFilterRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveIRBroadCastRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveIRShuffleRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveJoinRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveJoinRel.JoinAlgorithm;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveJoinRel.MapJoinStreamingRelation;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveLimitRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveProjectRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveRel;
import org.eigenbase.rel.RelNode;
import org.eigenbase.rel.rules.RemoveTrivialProjectRule;
import org.eigenbase.relopt.RelOptCluster;
import org.eigenbase.relopt.RelOptUtil;
import org.eigenbase.relopt.volcano.RelSubset;
import org.eigenbase.reltype.RelDataType;
import org.eigenbase.reltype.RelDataTypeField;
import org.eigenbase.rex.RexInputRef;
import org.eigenbase.rex.RexNode;
import org.eigenbase.rex.RexUtil;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;


public class OptiqUtil {
  public static <T> boolean orderedSubset(List<T> list1, List<T> list2) {
    List<T> lstToCompare = list1;
    if (list1.size() > list2.size()) {
      lstToCompare = list1.subList(0, list2.size());
    }
    if (lstToCompare.equals(list2)) {
      return true;
    }

    return false;
  }

  public static <T> boolean orderedSubset(ImmutableSet<ImmutableList<T>> setOfList1, List<T> list2) {
    for (List<T> lst: setOfList1) {
      if (orderedSubset(lst, list2)) {
        return true;
      }
    }

    return false;
  }

  public static JoinPredicateInfo getJoinPredicateInfo(HiveJoinRel j) {
    JoinPredicateInfo jpi = j.getJoinPredicateInfo();

    if (jpi == null) {
      jpi = new JoinPredicateInfo();
      RexNode jc = j.getCondition();

      if (jc != null) {
        List<RelDataTypeField> sysFieldList = new LinkedList<RelDataTypeField>();
        List<RexNode> leftJoinKeys = new LinkedList<RexNode>();
        List<RexNode> rightJoinKeys = new LinkedList<RexNode>();
        List<Integer> filterNulls = new LinkedList<Integer>();

        RexNode remainingNonJoinConjuctivePredicate = RelOptUtil.splitJoinCondition(sysFieldList,
            j.getLeft(), j.getRight(), j.getCondition(),
            leftJoinKeys, rightJoinKeys, filterNulls, null);

        List<Integer> joinKeysFromLeftRelations = getIndexList(leftJoinKeys);
        List<Integer> joinKeysFromRightRelations = getIndexList(rightJoinKeys);

        jpi.setJoinKeysFromLeftRelations(joinKeysFromLeftRelations);
        jpi.setJoinKeysFromRightRelations(joinKeysFromRightRelations);
        jpi.computeJoinKeysInJoinSchema(j.getLeft().getRowType().getFieldCount());
        if (remainingNonJoinConjuctivePredicate != null) {
          jpi.setNonJoinKeyLeafPredicates(RelOptUtil
              .conjunctions(remainingNonJoinConjuctivePredicate));
        }
      }

      j.setJoinPredicateInfo(jpi);
    }

    return jpi;
  }

  // TODO: Is this needed (Could RelSubSet ever be child of a node?)
  public static HiveRel getNonSubsetRelNode(RelNode n) {
    if (n instanceof RelSubset) {
      return ((HiveRel) ((RelSubset) n).getBest());
    } else {
      return ((HiveRel) n);
    }
  }

  public static Map<Integer, Integer> translateChildColPosToParent(HiveJoinRel j,
      boolean translateLeft) {
    HiveRel childToTranslateFrom = null;
    int colPosOffSet = 0;
    Map<Integer, Integer> projMapFromChildToParent = new HashMap<Integer, Integer>();

    if (translateLeft) {
      childToTranslateFrom = getNonSubsetRelNode(j.getLeft());
    } else {
      childToTranslateFrom = getNonSubsetRelNode(j.getRight());
      colPosOffSet = j.getLeft().getRowType().getFieldCount();
    }
    for (int i = 0; i < childToTranslateFrom.getRowType().getFieldCount(); i++) {
      projMapFromChildToParent.put(i, i + colPosOffSet);
    }

    return projMapFromChildToParent;
  }

  public static Map<Integer, Integer> translateChildColPosToParent(List<RexNode> exps) {
    Map<Integer, Integer> projMapFromChildToParent = new HashMap<Integer, Integer>();
    for (int i = 0; i < exps.size(); i++) {
      if (exps.get(i) instanceof RexInputRef) {
        projMapFromChildToParent.put(((RexInputRef) exps.get(i)).getIndex(), i);
      }
    }
    return projMapFromChildToParent;
  }

  public static List<Integer> translateChildColPosToParent(
      Map<Integer, Integer> projMapFromChildToParent,
      List<Integer> childPosLst, boolean allowForPartialTranslation) {
    Integer posInParent = null;
    List<Integer> translatedPos = new LinkedList<Integer>();

    for (Integer childPos : childPosLst) {
      posInParent = projMapFromChildToParent.get(childPos);
      if (posInParent == null)
      {
        if (!allowForPartialTranslation) {
          translatedPos = null;
        }
        break;
      }

      translatedPos.add(posInParent);
    }

    return translatedPos;
  }

  public static ImmutableSet<ImmutableList<Integer>> translateChildColPosToParent(
      Map<Integer, Integer> projMapFromChildToParent,
      ImmutableSet<ImmutableList<Integer>> childPosLstImmutableSet,
      boolean allowForPartialTranslation) {
    Set<ImmutableList<Integer>> childPosLstMutableSet = new HashSet<ImmutableList<Integer>>();

    List<Integer> translatedPos = null;
    for (List<Integer> childPosLst : childPosLstImmutableSet) {
      translatedPos = translateChildColPosToParent(projMapFromChildToParent, childPosLst,
          allowForPartialTranslation);
      if (translatedPos != null && !translatedPos.isEmpty()) {
        childPosLstMutableSet.add(ImmutableList.<Integer> copyOf(translatedPos));
      }
    }

    if (!childPosLstMutableSet.isEmpty()) {
      return ImmutableSet.<ImmutableList<Integer>> copyOf(childPosLstMutableSet);
    } else {
      return null;
    }
  }

  // projIndxInParentLst can not contain any Virtual Col
  public static Pair<List<Integer>, List<Integer>> translateProjIndxToChild(HiveJoinRel parentJoin,
      List<Integer> projIndxInParentLst) {
    if (projIndxInParentLst == null) {
      return null;
    }

    List<Integer> leftChildProj = new LinkedList<Integer>();
    List<Integer> rightChildProj = new LinkedList<Integer>();


    int rightOffSet = parentJoin.getLeft().getRowType().getFieldCount();
    for (Integer projIndx : projIndxInParentLst) {
      if (projIndx < rightOffSet) {
        leftChildProj.add(projIndx);
      } else {
        rightChildProj.add(projIndx - rightOffSet);
      }
    }

    return new Pair<List<Integer>, List<Integer>>(leftChildProj, rightChildProj);
  }

  // projIndxInParentLst can not contain any Virtual Col
  public static List<Integer> translateProjIndxToChild(HiveRel parentRel,
      List<Integer> projIndxInParentLst) {
    List<Integer> childProj = new LinkedList<Integer>();
    try {
      for (Integer projIndx : projIndxInParentLst) {
        RexNode field = parentRel.getChildExps().get(projIndx);
        childProj.add(((RexInputRef) field).getIndex());
      }
    } catch (Exception e) {
      // TODO Log here
      childProj = null;
    }
    return childProj;
  }

  public static List<Integer> translateBitSetToProjIndx(BitSet projBitSet) {
    List<Integer> projIndxLst = new LinkedList<Integer>();

    for (int i = 0; i < projBitSet.length(); i++) {
      if (projBitSet.get(i)) {
        projIndxLst.add(i);
      }
    }

    return projIndxLst;
  }

  private static List<Integer> getIndexList(List<RexNode> lstOfJoinKeysFromChildRel) {
    List<Integer> indexLst = new LinkedList<Integer>();

    for (RexNode r : lstOfJoinKeysFromChildRel) {
      if (r instanceof RexInputRef) {
        indexLst.add(((RexInputRef) r).getIndex());
      } else {
        // TODO: validate this
        throw new RuntimeException("Invalid rex node");
      }
    }

    return indexLst;
  }


  public static class JoinPredicateInfo {
    private List<RexNode> m_nonJoinKeyLeafPredicates;
    private List<Integer> m_joinKeysFromLeftRelations;
    private List<Integer> m_joinKeysFromRightRelations;
    private final List<Integer> m_joinKeysInJoinNodeSchemaFromLeft = new LinkedList<Integer>();
    private final List<Integer> m_joinKeysInJoinNodeSchemaFromRight = new LinkedList<Integer>();

    private void setNonJoinKeyLeafPredicates(List<RexNode> nonJoiningPredicates) {
      m_nonJoinKeyLeafPredicates = nonJoiningPredicates;
    }

    public boolean containsVirtualColumns(RelNode rel, Set<Integer> colSet) {
      boolean containsVC = false;

      List<RelDataTypeField> dtLst = rel.getRowType().getFieldList();
      for (Integer col : colSet) {
        if (!(dtLst.get(col) instanceof RexInputRef)) {
          containsVC = true;
          break;
        }
      }

      return containsVC;
    }


    private void computeJoinKeysInJoinSchema(int leftRelFiledCount) {
      if (m_joinKeysFromLeftRelations != null) {
        for (Integer k : m_joinKeysFromLeftRelations) {
          m_joinKeysInJoinNodeSchemaFromLeft.add(k);
        }
      }

      if (m_joinKeysFromRightRelations != null) {
        for (Integer k : m_joinKeysFromRightRelations) {
          m_joinKeysInJoinNodeSchemaFromRight.add(leftRelFiledCount + k);
        }
      }
    }

    public List<Integer> getJoinKeysInJoinSchemaFromLeft() {
      return m_joinKeysInJoinNodeSchemaFromLeft;
    }

    public List<Integer> getJoinKeysInJoinSchemaFromRight() {
      return m_joinKeysInJoinNodeSchemaFromRight;
    }

    public List<RexNode> getNonJoinKeyLeafPredicates() {
      return m_nonJoinKeyLeafPredicates;
    }

    private void setJoinKeysFromLeftRelations(List<Integer> keyLst) {
      m_joinKeysFromLeftRelations = keyLst;
    }

    public List<Integer> getJoinKeysFromLeftRelation() {
      return m_joinKeysFromLeftRelations;
    }

    private void setJoinKeysFromRightRelations(List<Integer> keyLst) {
      m_joinKeysFromRightRelations = keyLst;
    }

    public List<Integer> getJoinKeysFromRightRelation() {
      return m_joinKeysFromRightRelations;
    }
  }

  public static HiveJoinRel introduceShuffleOperator(HiveJoinRel origJoin,
      boolean introduceShuffleAtLeft, boolean introduceShuffleAtRight,
      List<Integer> leftSortKeys, List<Integer> rightSortKeys) {
    HiveRel leftOfNewJoin = (HiveRel) origJoin.getLeft();
    HiveRel rightOfNewJoin = (HiveRel) origJoin.getRight();

    if (introduceShuffleAtLeft) {
      leftOfNewJoin = new HiveIRShuffleRel(leftOfNewJoin.getCluster(), leftOfNewJoin.getTraitSet(),
          leftSortKeys, leftOfNewJoin);
    }
    if (introduceShuffleAtLeft) {
      rightOfNewJoin = new HiveIRShuffleRel(rightOfNewJoin.getCluster(),
          rightOfNewJoin.getTraitSet(), rightSortKeys, rightOfNewJoin);
    }

    HiveJoinRel newJoin = origJoin.copy(origJoin.getTraitSet(),
        origJoin.getCondition(),
        leftOfNewJoin,
        rightOfNewJoin, JoinAlgorithm.COMMON_JOIN, MapJoinStreamingRelation.NONE);

    return newJoin;
  }

  public static HiveJoinRel introduceBroadcastOperator(HiveJoinRel origJoin,
      MapJoinStreamingRelation m_streamingSide) {
    HiveRel leftOfNewJoin = (HiveRel) origJoin.getLeft();
    HiveRel rightOfNewJoin = (HiveRel) origJoin.getRight();

    if (m_streamingSide == MapJoinStreamingRelation.LEFT_RELATION) {
      rightOfNewJoin = new HiveIRBroadCastRel(rightOfNewJoin.getCluster(),
          rightOfNewJoin.getTraitSet(), (HiveRel) origJoin.getRight());
    } else {
      leftOfNewJoin = new HiveIRBroadCastRel(leftOfNewJoin.getCluster(),
          leftOfNewJoin.getTraitSet(), (HiveRel) origJoin.getLeft());
    }

    HiveJoinRel newJoin = origJoin.copy(origJoin.getTraitSet(),
        origJoin.getCondition(),
        leftOfNewJoin,
        rightOfNewJoin, JoinAlgorithm.MAP_JOIN, m_streamingSide);

    return newJoin;
  }

  public static RelNode createProjectIfNeeded(final HiveRel child,
      final List<Integer> posList) {
    if (isIdentity(posList, child.getRowType().getFieldCount())) {
      return child;
    } else {
      List<RexNode> inputRefs = constructInputRefs(child, posList);
      return new HiveProjectRel(child.getCluster(), child, inputRefs, null, 0);
    }
  }

  public static RelNode createProjectIfNeeded(final HiveRel child, List<RexNode> exps,
      List<String> fieldNames) {
    final RelOptCluster cluster = child.getCluster();
    final RelDataType rowType =
        RexUtil.createStructType(
            cluster.getTypeFactory(),
            exps,
            fieldNames);
    if (RemoveTrivialProjectRule.isIdentity(
        exps,
        rowType,
        child.getRowType())) {
      return child;
    }
    return new HiveProjectRel(child.getCluster(), child, exps, null, 0);
  }

  private static List<RexNode> constructInputRefs(final HiveRel child, List<Integer> projPosLst) {
    RexNode inputRef;
    final List<RexNode> projExps = new LinkedList<RexNode>();

    for (Integer pos : projPosLst) {
      inputRef = child.getCluster().getRexBuilder().makeInputRef(
          child.getRowType().getFieldList().get(pos).getType(),
          pos);
      projExps.add(inputRef);
    }

    return projExps;
  }

  private static boolean isIdentity(List<Integer> list, int count) {
    if (list.size() != count) {
      return false;
    }
    for (int i = 0; i < count; i++) {
      final Integer o = list.get(i);
      if (o == null || o != i) {
        return false;
      }
    }
    return true;
  }

  public static boolean isAlreadyStreamingWithinSameVertex(HiveRel n) {
    if (n instanceof HiveProjectRel || n instanceof HiveFilterRel || n instanceof HiveLimitRel) {
      return isAlreadyStreamingWithinSameVertex((HiveRel) n.getInput(0));
    } else if (n instanceof HiveJoinRel || n instanceof HiveAggregateRel) {
      return true;
    }

    return false;
  }
}
