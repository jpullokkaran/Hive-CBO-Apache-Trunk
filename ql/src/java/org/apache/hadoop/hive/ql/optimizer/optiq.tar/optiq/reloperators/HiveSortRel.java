package org.apache.hadoop.hive.ql.optimizer.optiq.reloperators;

import java.util.LinkedList;
import java.util.List;

import org.apache.hadoop.hive.ql.optimizer.optiq.OptiqTraitsUtil;
import org.apache.hadoop.hive.ql.optimizer.optiq.OptiqUtil;
import org.apache.hadoop.hive.ql.optimizer.optiq.RelBucketing;
import org.apache.hadoop.hive.ql.optimizer.optiq.stats.OptiqStatsUtil;
import org.eigenbase.rel.RelCollation;
import org.eigenbase.rel.RelNode;
import org.eigenbase.rel.SortRel;
import org.eigenbase.relopt.RelOptCluster;
import org.eigenbase.relopt.RelTraitSet;
import org.eigenbase.rex.RexNode;

public class HiveSortRel extends SortRel implements HiveRel {
  private final List<Double> m_columnSizeLst = new LinkedList<Double>();
  private final Double m_avgSize;

  public HiveSortRel(RelOptCluster cluster, RelTraitSet traitSet,
      RelNode child, RelCollation collation, RexNode offset, RexNode fetch) {
    super(cluster, OptiqTraitsUtil.getSortTraitSet(cluster, traitSet, collation), child, collation, offset, fetch);
    assert getConvention() instanceof HiveRel;
    assert getConvention() == child.getConvention();

    HiveRel hiveChildNode = OptiqUtil.getNonSubsetRelNode(child);
    m_avgSize = hiveChildNode.getColumnAvgSize();
    m_columnSizeLst.addAll(hiveChildNode.getColumnAvgSize(null));
  }

  @Override
  public HiveSortRel copy(
      RelTraitSet traitSet,
      RelNode newInput,
      RelCollation newCollation,
      RexNode offset,
      RexNode fetch) {
    // TODO: can we blindly copy sort trait? What if inputs changed and we are now sorting by
    // different cols
    return new HiveSortRel(
        getCluster(),
        traitSet,
        newInput,
        newCollation,
        offset,
        fetch);
  }

  public void implement(Implementor implementor) {
  }

  @Override
  public Double getColumnAvgSize() {
    return m_avgSize;
  }

  @Override
  public List<Double> getColumnAvgSize(List<Integer> projIndxLst) {
    if (projIndxLst != null) {
      List<Double> sizeLst = new LinkedList<Double>();

      for (Integer projIdx : projIndxLst) {
        sizeLst.add(m_columnSizeLst.get(projIdx));
      }
      return sizeLst;
    } else {
      return m_columnSizeLst;
    }
  }

  @Override
  public Double getColumnAvgSize(int projIndx) {
    return m_columnSizeLst.get(projIndx);
  }

  @Override
  public Double getEstimatedMemUsageInVertex() {
    return getColumnAvgSize() * ((HiveRel)getChild()).getDegreeOfParallelization();
  }

  @Override
  public Integer getDegreeOfParallelization() {
    return 0;
  }

  @Override
  public Long getNDV(List<Integer> colOrderLst) {
    return OptiqStatsUtil.computeNDV(this, colOrderLst);
  }

  @Override
  public boolean propagateBucketingTraitUpwardsViaTransformation(List<Integer> bucketingCols, List<Integer> bucketSortCols){
    return false;
  }

  @Override
  public boolean propagateSortingTraitUpwardsViaTransformation(List<Integer> sortingCols) {
    return false;
  }

  @Override
  public boolean shouldPropagateTraitFromChildViaTransformation(RelBucketing bucketTraitFromChild) {
    return false;
  }

  @Override
  public boolean shouldPropagateTraitFromChildViaTransformation(RelCollation sortTraitFromChild) {
    return false;
  }
}
