package org.apache.hadoop.hive.ql.optimizer.optiq.stats;

import java.util.LinkedList;
import java.util.List;

import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveAggregateRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveFilterRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveJoinRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveLimitRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveProjectRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveSortRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveTableScanRel;
import org.apache.hadoop.hive.ql.optimizer.optiq.reloperators.HiveUnionRel;
import org.eigenbase.rel.WindowRelBase.RexWinAggCall;
import org.eigenbase.rex.RexCorrelVariable;
import org.eigenbase.rex.RexDynamicParam;
import org.eigenbase.rex.RexFieldAccess;
import org.eigenbase.rex.RexInputRef;
import org.eigenbase.rex.RexLiteral;
import org.eigenbase.rex.RexLocalRef;
import org.eigenbase.rex.RexNode;
import org.eigenbase.rex.RexOver;
import org.eigenbase.rex.RexRangeRef;
import org.eigenbase.util.NlsString;

public class OptiqStatsUtil {

  /*** Memory Computation ***/
  public static List<Double> computeProjAvgSize(List<RexNode> exps, HiveRel child) {
    List<Double> lstOfProjSizes = new LinkedList<Double>();

    for (RexNode expNode : exps) {
      lstOfProjSizes.add(getAvgSize(expNode, child));
    }

    return lstOfProjSizes;
  }

  private static Double getAvgSize(RexNode exp, HiveRel child) {
    Double avgSize = 0.0;

    if (exp instanceof RexInputRef) {
      avgSize = child.getColumnAvgSize(((RexInputRef) exp).getIndex());
    } else if (exp instanceof RexCorrelVariable) {
      // DO Nothing, return size of 0
    } else if (exp instanceof RexDynamicParam) {
      // TODO: is the index valid? does it point to child schema element?
      avgSize = child.getColumnAvgSize(((RexDynamicParam) exp).getIndex());
    } else if (exp instanceof RexLocalRef) {
      // TODO: is the index valid? does it point to child schema element?
      avgSize = child.getColumnAvgSize(((RexLocalRef) exp).getIndex());
    } else if (exp instanceof RexOver) {
      avgSize = getMaxAvgSize(((RexOver) exp).getOperands(), child);
    } else if (exp instanceof RexWinAggCall) {
      avgSize = getMaxAvgSize(((RexWinAggCall) exp).getOperands(), child);
    } else if (exp instanceof RexFieldAccess) {
      //TODO: How do we know if RexFieldAccess is referring to its child node's schema
      avgSize = child.getColumnAvgSize(((RexFieldAccess)exp).getField().getIndex());
    } else if (exp instanceof RexLiteral) {
      avgSize = getSizeOfLiteral((RexLiteral) exp);
    } else if (exp instanceof RexRangeRef) {

    }

    return avgSize;
  }

  //TODO: 1) size should be the size of the value in Hive.
  // Size calculations for literals is complicated due to sharing of immutable in JVM
  // 2) Evaluate the sizes, may not be correct?
  private static Double getSizeOfLiteral(RexLiteral literal) {
    Double sz = 0.0;

    switch (literal.getTypeName()) {
    case ANY:
      break;
    case ARRAY:
      break;
    case DOUBLE:
    case DECIMAL:
      sz = 8.0;
      break;
    case FLOAT:
    case REAL:
      sz = 4.0;
      break;
    case TINYINT:
      sz = 1.0;
      break;
    case SMALLINT:
      sz = 2.0;
      break;
    case INTEGER:
      sz = 4.0;
      break;
    case BIGINT:
      sz = 8.0;
      break;
    case INTERVAL_DAY_TIME:
    case INTERVAL_YEAR_MONTH:
    case DATE:
    case TIME:
    case TIMESTAMP:
      sz = 12.0;
      break;

    case BOOLEAN:
      sz = 1.0;
      break;

    case CHAR:
    case VARCHAR:
      if (literal.getValue() instanceof NlsString) {
        sz = (double) (((NlsString)(literal.getValue())).getValue().length() * 2);
      }
      break;

    case BINARY:
      break;
    case VARBINARY:
      break;

    case COLUMN_LIST:
      break;
    case CURSOR:
      break;
    case DISTINCT:
      break;
    case MAP:
      break;
    case MULTISET:
      break;
    case NULL:
      break;
    case OTHER:
      break;
    case ROW:
      break;
    case STRUCTURED:
      break;
    case SYMBOL:
      break;
    default:
      break;
    }

    return sz;
  }

  private static Double getMaxAvgSize(List<RexNode> expLst, HiveRel child) {
    Double avgSize = 0.0;
    Double tmpSize = 0.0;
    for (RexNode exp : expLst) {
      tmpSize = getAvgSize(exp, child);
      if (tmpSize > avgSize) {
        avgSize = tmpSize;
      }
    }

    return avgSize;
  }
  /*
   * private static List<Double> getAvgSize(List<RexInputRef> refLst, HiveRel child) {
   * List<Integer> projIdxLst = new LinkedList<Integer>();
   * List<Double> projAvgSizeLst;
   *
   * for (RexInputRef inRef : refLst) {
   * projIdxLst.add(inRef.getIndex());
   * }
   * projAvgSizeLst = child.getColumnAvgSize(projIdxLst);
   *
   * return projAvgSizeLst;
   * }
   *
   * private static Double getAvgSize(RexNode func, HiveRel child) {
   * List<Integer> projIdxLst = new LinkedList<Integer>();
   * List<Double> projAvgSizeLst;
   *
   * for (RexInputRef inRef : refLst) {
   * projIdxLst.add(inRef.getIndex());
   * }
   * projAvgSizeLst = child.getColumnAvgSize(projIdxLst);
   *
   * return projAvgSizeLst;
   * }
   */

  /********** NDV Computation *********/
  public static long computeNDV(HiveAggregateRel hiveAggregateRel, List<Integer> colOrderLst) {
    // TODO Auto-generated method stub
    return 0;
  }

  public static long computeNDV(HiveFilterRel hiveFilterRel, List<Integer> colOrderLst) {
    // TODO Auto-generated method stub
    return 0;
  }

  public static long computeNDV(HiveJoinRel hiveJoinRel, List<Integer> colOrderLst) {
    return 0;
  }

  public static long computeNDV(HiveLimitRel hiveLimitRel, List<Integer> colOrderLst) {
    return 0;
  }

  public static long computeNDV(HiveProjectRel hiveProjectRel, List<Integer> colOrderLst) {
    return 0;
  }

  public static long computeNDV(HiveSortRel hiveSortRel, List<Integer> colOrderLst) {
    return 0;
  }

  public static long computeNDV(HiveTableScanRel hiveTableScanRel, List<Integer> colOrderLst) {
    return 0;
  }

  public static long computeNDV(HiveUnionRel hiveUnionRel, List<Integer> colOrderLst) {
    return 0;
  }
}
