package org.apache.hadoop.hive.ql.optimizer.optiq.reloperators;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hive.ql.optimizer.optiq.RelBucketing;
import org.eigenbase.rel.RelCollation;
import org.eigenbase.rel.RelNode;
import org.eigenbase.relopt.Convention;

public interface HiveRel extends RelNode {

  final Map<Integer, Double> m_columnIdxToSizeMap = new HashMap<Integer, Double>();

  Double m_avgSize = -1.0;


  void implement(Implementor implementor);

  /** Calling convention for relational operations that occur in MongoDB. */
  final Convention CONVENTION = new Convention.Impl("HIVE", HiveRel.class);

  class Implementor {

    public void visitChild(int ordinal, RelNode input) {
      assert ordinal == 0;
      ((HiveRel) input).implement(this);
    }
  }

  /**
   * Get average size of the tuple that includes all columns of this operator.
   *
   * @return double Size of the tuple
   */
  public Double getColumnAvgSize();

  /**
   * Get average size of the tuple that is composed of given projections.
   *
   * @param projIndxLst
   *          List of projection indexes that is part of the tuple. If null, sizes of all
   *          projections of this node will be returned.
   * @return double average size of the tuple.
   */
  public List<Double> getColumnAvgSize(List<Integer> projIndxLst);

  /**
   * Get average size of the projection.
   *
   * @param projIndx
   *          Index of the projection in the tuple.
   * @return Double average size of the projection.
   */
  public Double getColumnAvgSize(int projIndx);

  /**
   * Get max memory used so far with in the physical process boundary.
   * This sums up the memory consumption of each operator in the process boundary.
   *
   * @return Double Estimated memory usage of this node.
   */
  public Double getEstimatedMemUsageInVertex();

  /**
   * Get degree of parallelization of the node.
   *
   * @return
   */
  public Integer getDegreeOfParallelization();

  /**
   * Get NDV.
   */
  public Long getNDV(List<Integer> colOrderLst);

  /**
   * Propagate requested bucketing trait upwards if possible
   *
   * @return true if this node will propagate requested bucketing  trait.
   */
  public boolean propagateBucketingTraitUpwardsViaTransformation(List<Integer> bucketingCols, List<Integer> bucketSortCols);

  /**
   * Propagate requested sorting Trait upwards if possible
   */
  public boolean propagateSortingTraitUpwardsViaTransformation(List<Integer> sortingCols);

  /**
   * Should propagate bucketing trait from child Node?
   * @param bucketTraitFromChild TODO
   */
  public boolean shouldPropagateTraitFromChildViaTransformation(RelBucketing bucketTraitFromChild);

  /**
   * Should propagate sorting trait from child Node?
   */
  public boolean shouldPropagateTraitFromChildViaTransformation(RelCollation sortTraitFromChild);
}
