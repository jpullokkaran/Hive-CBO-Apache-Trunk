package org.apache.hadoop.hive.ql.optimizer.optiq.reloperators;

import java.util.List;

import org.apache.hadoop.hive.ql.optimizer.optiq.OptiqTraitsUtil;
import org.eigenbase.relopt.RelOptCluster;
import org.eigenbase.relopt.RelTraitSet;

public class HiveIRBroadCastRel extends HiveIRRel {

  public HiveIRBroadCastRel(RelOptCluster cluster, RelTraitSet traitSet, HiveRel child) {
    super(cluster, OptiqTraitsUtil.getIRBroadcastApplicableTraitSet(cluster, traitSet, child), child);
  }

  @Override
  public Double getEstimatedMemUsageInVertex() {
    return ((HiveRel)getChild()).getRows() * ((HiveRel)getChild()).getColumnAvgSize();
  }

  @Override
  public Integer getDegreeOfParallelization() {
    return 0;
  }

  @Override
  public Long getNDV(List<Integer> colOrderLst) {
    return ((HiveRel)getChild()).getNDV(colOrderLst);
  }
}
