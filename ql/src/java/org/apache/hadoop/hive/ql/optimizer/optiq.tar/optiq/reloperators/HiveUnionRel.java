package org.apache.hadoop.hive.ql.optimizer.optiq.reloperators;

import java.util.LinkedList;
import java.util.List;

import org.apache.hadoop.hive.ql.optimizer.optiq.OptiqTraitsUtil;
import org.apache.hadoop.hive.ql.optimizer.optiq.OptiqUtil;
import org.apache.hadoop.hive.ql.optimizer.optiq.RelBucketing;
import org.apache.hadoop.hive.ql.optimizer.optiq.stats.OptiqStatsUtil;
import org.eigenbase.rel.RelCollation;
import org.eigenbase.rel.RelNode;
import org.eigenbase.rel.UnionRelBase;
import org.eigenbase.relopt.RelOptCluster;
import org.eigenbase.relopt.RelTraitSet;

public class HiveUnionRel extends UnionRelBase implements HiveRel {
  private final List<Double> m_columnSizeLst = new LinkedList<Double>();
  private final Double m_avgSize;

  public HiveUnionRel(
      RelOptCluster cluster,
      RelTraitSet traitSet,
      List<RelNode> inputs,
      boolean all) {
    super(cluster, OptiqTraitsUtil.getHiveTraitSet(cluster, traitSet), inputs, all);

    HiveRel hiveChildNode;
    Double totalAvgSz = 0.0;
    List<Double> lstAvgColumnSzFromChild = null;
    for (RelNode child : inputs) {
      hiveChildNode = OptiqUtil.getNonSubsetRelNode(child);
      totalAvgSz += hiveChildNode.getColumnAvgSize();

      lstAvgColumnSzFromChild = hiveChildNode.getColumnAvgSize(null);
      if (m_columnSizeLst.isEmpty()) {
        m_columnSizeLst.addAll(lstAvgColumnSzFromChild);
      } else {
        for (int i = 0; i < m_columnSizeLst.size(); i++) {
          m_columnSizeLst.set(i, m_columnSizeLst.get(i) + lstAvgColumnSzFromChild.get(i));
        }
      }
    }

    int noOfInputs = inputs.size();
    m_avgSize = (totalAvgSz / noOfInputs);
    for (int i = 0; i < m_columnSizeLst.size(); i++) {
      m_columnSizeLst.set(i, m_columnSizeLst.get(i) / noOfInputs);
    }
  }

  @Override
  public HiveUnionRel copy(
      RelTraitSet traitSet, List<RelNode> inputs, boolean all) {
    return new HiveUnionRel(getCluster(), traitSet, inputs, all);
  }

  public void implement(Implementor implementor) {
  }


  @Override
  public Double getColumnAvgSize() {
    return m_avgSize;
  }

  @Override
  public List<Double> getColumnAvgSize(List<Integer> projIndxLst) {
    if (projIndxLst != null) {
      List<Double> sizeLst = new LinkedList<Double>();

      for (Integer projIdx : projIndxLst) {
        sizeLst.add(m_columnSizeLst.get(projIdx));
      }
      return sizeLst;
    } else {
      return m_columnSizeLst;
    }
  }

  @Override
  public Double getColumnAvgSize(int projIndx) {
    return m_columnSizeLst.get(projIndx);
  }

  @Override
  public Double getEstimatedMemUsageInVertex() {
    return getColumnAvgSize();
  }

  @Override
  public Integer getDegreeOfParallelization() {
    return 0;
  }

  @Override
  public Long getNDV(List<Integer> colOrderLst) {
    return OptiqStatsUtil.computeNDV(this, colOrderLst);
  }

  @Override
  public boolean propagateBucketingTraitUpwardsViaTransformation(List<Integer> bucketingCols, List<Integer> bucketSortCols){
    return false;
  }

  @Override
  public boolean propagateSortingTraitUpwardsViaTransformation(List<Integer> sortingCols) {
    return false;
  }

  @Override
  public boolean shouldPropagateTraitFromChildViaTransformation(RelBucketing bucketTraitFromChild) {
    return false;
  }

  @Override
  public boolean shouldPropagateTraitFromChildViaTransformation(RelCollation sortTraitFromChild) {
    return false;
  }
}
