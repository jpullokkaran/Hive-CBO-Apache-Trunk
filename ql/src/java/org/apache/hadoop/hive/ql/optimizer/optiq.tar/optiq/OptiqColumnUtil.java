package org.apache.hadoop.hive.ql.optimizer.optiq;

import org.eigenbase.rex.RexNode;

public class OptiqColumnUtil {
RexNode translateInTermsOfOrigin(RexNode columnToTranslate) {
  if ( {
    return null;
  }
}
}
